package com.teste.teste.Servico;

import com.teste.teste.Entidade.Pauta;
import com.teste.teste.Entidade.Academico;
import com.teste.teste.Entidade.Disciplina;
import com.teste.teste.Repositorio.PautaRepositorio;
import com.teste.teste.Repositorio.AcademicoRepositorio;
import com.teste.teste.Repositorio.DisciplinaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PautaServico {

    @Autowired
    private PautaRepositorio pautaRepositorio;

    @Autowired
    private AcademicoRepositorio academicoRepositorio;

    @Autowired
    private DisciplinaRepositorio disciplinaRepositorio;

    @Transactional
    public Pauta salvarPauta(Pauta pauta, Integer academicoId, Integer disciplinaId) {
        Academico academico = academicoRepositorio.findById(academicoId).orElseThrow(() -> new RuntimeException("Academico não encontrado"));
        Disciplina disciplina = disciplinaRepositorio.findById(disciplinaId).orElseThrow(() -> new RuntimeException("Disciplina não encontrada"));

        pauta.setAcademico(academico);
        pauta.setDisciplina(disciplina);

        return pautaRepositorio.save(pauta);
    }

    @Transactional
    public Pauta obterPautaPorId(Integer id) {
        return pautaRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public void deletarPauta(Integer id) {
        pautaRepositorio.deleteById(id);
    }

    @Transactional
    public List<Pauta> listarPautas() {
        return pautaRepositorio.findAll();
    }
}
