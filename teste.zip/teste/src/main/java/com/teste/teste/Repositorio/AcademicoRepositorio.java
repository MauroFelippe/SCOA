package com.teste.teste.Repositorio;

import com.teste.teste.Entidade.Academico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface AcademicoRepositorio extends JpaRepository<Academico, Integer> {
}
