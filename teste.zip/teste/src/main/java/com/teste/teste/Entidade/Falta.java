package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "FALTA")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Falta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_falta")
    private int idFalta;

    @Column(name = "Datas", nullable = false, length = 50)
    private String datas;

    @Column(name = "Motivo", nullable = false, length = 50)
    private String motivo;

    @Column(name = "Status", nullable = false)
    private boolean status;

    @ManyToOne
    @JoinColumn(name = "Id_curso", nullable = false)
    private Curso curso;

    @ManyToOne
    @JoinColumn(name = "Matricula", nullable = false)
    private Aluno aluno;

    @ManyToOne
    @JoinColumn(name = "Id_funcionario", nullable = false)
    private Academico academico;
}