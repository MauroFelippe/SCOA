package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "USUARIO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "Id_usuario")
        private int id;

        @Column(name = "Email", nullable = false, length = 50)
        private String email;

        @Column(name = "Senha", nullable = false, length = 50)
        private String senha;

        @Column(name = "CPF", nullable = false, length = 14)
        private String cpf;

        @Column(name = "Nome", nullable = false, length = 50)
        private String nome;

        @Column(name = "Data_de_nascimento", nullable = false, length = 10)
        private String dataDeNascimento;
}

