package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Curso;
import com.teste.teste.Servico.CursoServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cursos")
public class CursoControl {

    @Autowired
    private CursoServico cursoServico;

    @PostMapping
    public Curso salvarCurso(@RequestBody Curso curso) {
        return cursoServico.salvarCurso(curso);
    }

    @GetMapping("/{id}")
    public Curso obterCursoPorId(@PathVariable Integer id) {
        return cursoServico.obterCursoPorId(id);
    }

    @GetMapping
    public List<Curso> listarCursos() {
        return cursoServico.listarCursos();
    }

    @DeleteMapping("/{id}")
    public void deletarCurso(@PathVariable Integer id) {
        cursoServico.deletarCurso(id);
    }
}
