package com.teste.teste.Servico;

import com.teste.teste.Entidade.Falta;
import com.teste.teste.Entidade.Curso;
import com.teste.teste.Entidade.Aluno;
import com.teste.teste.Entidade.Academico;
import com.teste.teste.Repositorio.FaltaRepositorio;
import com.teste.teste.Repositorio.CursoRepositorio;
import com.teste.teste.Repositorio.AlunoRepositorio;
import com.teste.teste.Repositorio.AcademicoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FaltaServico {

    @Autowired
    private FaltaRepositorio faltaRepositorio;

    @Autowired
    private CursoRepositorio cursoRepositorio;

    @Autowired
    private AlunoRepositorio alunoRepositorio;

    @Autowired
    private AcademicoRepositorio academicoRepositorio;

    @Transactional
    public Falta salvarFalta(Falta falta, Integer cursoId, Long alunoMatricula, Integer academicoId) {
        Curso curso = cursoRepositorio.findById(cursoId).orElseThrow(() -> new RuntimeException("Curso não encontrado"));
        Aluno aluno = alunoRepositorio.findById(alunoMatricula).orElseThrow(() -> new RuntimeException("Aluno não encontrado"));
        Academico academico = academicoRepositorio.findById(academicoId).orElseThrow(() -> new RuntimeException("Academico não encontrado"));

        falta.setCurso(curso);
        falta.setAluno(aluno);
        falta.setAcademico(academico);

        return faltaRepositorio.save(falta);
    }

    @Transactional
    public Falta obterFaltaPorId(Integer id) {
        return faltaRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public void deletarFalta(Integer id) {
        faltaRepositorio.deleteById(id);
    }

    @Transactional
    public List<Falta> listarFaltas() {
        return faltaRepositorio.findAll();
    }
}