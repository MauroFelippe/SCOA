package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Aluno;
import com.teste.teste.Servico.AlunoServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alunos")
public class AlunoControl {

    @Autowired
    private AlunoServico alunoServico;

    @PostMapping("/com-usuario/{usuarioId}")
    public Aluno salvarAlunoComUsuario(@RequestBody Aluno aluno, @PathVariable Integer usuarioId) {
        return alunoServico.salvarAluno(aluno, usuarioId);
    }

    @GetMapping("/{id}")
    public Aluno obterAlunoPorId(@PathVariable Long id) {
        return alunoServico.obterAlunoPorId(id);
    }

    @GetMapping
    public List<Aluno> listarAlunos() {
        return alunoServico.listarAlunos();
    }

    @DeleteMapping("/{id}")
    public void deletarAluno(@PathVariable Long id) {
        alunoServico.deletarAluno(id);
    }
}
