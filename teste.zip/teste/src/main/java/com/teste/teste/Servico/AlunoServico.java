package com.teste.teste.Servico;

import com.teste.teste.Entidade.Aluno;
import com.teste.teste.Entidade.Usuario;
import com.teste.teste.Repositorio.AlunoRepositorio;
import com.teste.teste.Repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class AlunoServico {

    @Autowired
    private AlunoRepositorio alunoRepositorio;

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Transactional
    public Aluno salvarAluno(Aluno aluno, Integer usuarioId) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId).orElseThrow(() -> new RuntimeException("Usuario não encontrado"));
        aluno.setUsuario(usuario);
        return alunoRepositorio.save(aluno);
    }

    @Transactional
    public Aluno obterAlunoPorId(Long id) {
        return alunoRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public void deletarAluno(Long id) {
        alunoRepositorio.deleteById(id);
    }

    @Transactional
    public List<Aluno> listarAlunos() {
        return alunoRepositorio.findAll();
    }
}
