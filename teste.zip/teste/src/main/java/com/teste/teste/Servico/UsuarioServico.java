package com.teste.teste.Servico;

import com.teste.teste.Entidade.Usuario;
import com.teste.teste.Repositorio.UsuarioRepositorio;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UsuarioServico {

    private final UsuarioRepositorio usuarioRepositorio;

    @Autowired
    public UsuarioServico(UsuarioRepositorio usuarioRepositorio) {
        this.usuarioRepositorio = usuarioRepositorio;
    }

    @Transactional
    public List<Usuario> listarUsuarios() {
        return usuarioRepositorio.findAll();
    }

    @Transactional
    public Usuario encontrarPorId(int id) {
        return usuarioRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public Usuario salvarUsuario(Usuario usuario) {
        return usuarioRepositorio.save(usuario);
    }

    @Transactional
    public void deletarUsuario(int id) {
        usuarioRepositorio.deleteById(id);
    }
}
