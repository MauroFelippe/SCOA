package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Falta;
import com.teste.teste.Servico.FaltaServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/faltas")
public class FaltaControl {

    @Autowired
    private FaltaServico faltaServico;

    @PostMapping("/com-detalhes/{cursoId}/{alunoMatricula}/{academicoId}")
    public Falta salvarFaltaComDetalhes(
            @RequestBody Falta falta,
            @PathVariable Integer cursoId,
            @PathVariable Long alunoMatricula,  
            @PathVariable Integer academicoId) {
        return faltaServico.salvarFalta(falta, cursoId, alunoMatricula, academicoId);
    }

    @GetMapping("/{id}")
    public Falta obterFaltaPorId(@PathVariable Integer id) {
        return faltaServico.obterFaltaPorId(id);
    }

    @GetMapping
    public List<Falta> listarFaltas() {
        return faltaServico.listarFaltas();
    }

    @DeleteMapping("/{id}")
    public void deletarFalta(@PathVariable Integer id) {
        faltaServico.deletarFalta(id);
    }
}