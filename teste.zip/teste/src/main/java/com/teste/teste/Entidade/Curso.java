package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "CURSO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_curso")
    private int idCurso;

    @Column(name = "Nome", nullable = false, length = 30)
    private String nome;

    @Column(name = "CH", nullable = false, length = 3)
    private String ch;

    @Column(name = "Descricao", nullable = false, length = 300)
    private String descricao;

    @Column(name = "Sala", nullable = false, length = 3)
    private String sala;

}