package com.teste.teste.Servico;

import com.teste.teste.Entidade.Disciplina;
import com.teste.teste.Entidade.Academico;
import com.teste.teste.Repositorio.DisciplinaRepositorio;
import com.teste.teste.Repositorio.AcademicoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DisciplinaServico {

    @Autowired
    private DisciplinaRepositorio disciplinaRepositorio;

    @Autowired
    private AcademicoRepositorio academicoRepositorio;

    @Transactional
    public Disciplina salvarDisciplina(Disciplina disciplina, Integer academicoId) {
        Academico academico = academicoRepositorio.findById(academicoId).orElseThrow(() -> new RuntimeException("Academico não encontrado"));
        disciplina.setAcademico(academico);
        return disciplinaRepositorio.save(disciplina);
    }

    @Transactional
    public Disciplina obterDisciplinaPorId(Integer id) {
        return disciplinaRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public void deletarDisciplina(Integer id) {
        disciplinaRepositorio.deleteById(id);
    }

    @Transactional
    public List<Disciplina> listarDisciplinas() {
        return disciplinaRepositorio.findAll();
    }
}