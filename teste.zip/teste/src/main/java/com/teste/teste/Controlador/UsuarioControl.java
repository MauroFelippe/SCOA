package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Usuario;
import com.teste.teste.Servico.UsuarioServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioControl {

    private final UsuarioServico usuarioServico;

    @Autowired
    public UsuarioControl(UsuarioServico usuarioService) {
        this.usuarioServico = usuarioService;
    }

    @GetMapping
    public List<Usuario> listarUsuarios() {
        return usuarioServico.listarUsuarios();
    }

    @GetMapping("/{id}")
    public Usuario encontrarPorId(@PathVariable int id) {
        return usuarioServico.encontrarPorId(id);
    }

    @PostMapping
    public Usuario salvarUsuario(@RequestBody Usuario usuario) {
        return usuarioServico.salvarUsuario(usuario);
    }

    @DeleteMapping("/{id}")
    public void deletarUsuario(@PathVariable int id) {
        usuarioServico.deletarUsuario(id);
    }
}