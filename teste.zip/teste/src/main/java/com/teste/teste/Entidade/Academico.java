package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ACADEMICO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Academico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_funcionario")
    private int idFuncionario;

    @Column(name = "Cargo", nullable = false, length = 15)
    private String cargo;

    @ManyToOne
    @JoinColumn(name = "Id_usuario", nullable = false)
    private Usuario usuario;
}