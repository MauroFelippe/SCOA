package com.teste.teste.Servico;

import com.teste.teste.Entidade.Usuario;
import com.teste.teste.Entidade.Academico;
import com.teste.teste.Repositorio.AcademicoRepositorio;
import com.teste.teste.Repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AcademicoServico {

    @Autowired
    private AcademicoRepositorio academicoRepositorio;

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Transactional
    public Academico salvarAcademico(Academico academico, Integer usuarioId) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId).orElseThrow(() -> new RuntimeException("Usuario não encontrado"));
        academico.setUsuario(usuario);
        return academicoRepositorio.save(academico);
    }

    @Transactional
    public Academico obterAcademicoPorId(Integer id) {
        return academicoRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public void deletarAcademico(Integer id) {
        academicoRepositorio.deleteById(id);
    }

    @Transactional
    public List<Academico> listarAcademicos() {
        return academicoRepositorio.findAll();
    }
}