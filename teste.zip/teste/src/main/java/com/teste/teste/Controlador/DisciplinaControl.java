package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Disciplina;
import com.teste.teste.Servico.DisciplinaServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/disciplinas")
public class DisciplinaControl {

    @Autowired
    private DisciplinaServico disciplinaServico;

    @PostMapping("/com-academico/{academicoId}")
    public Disciplina salvarDisciplinaComAcademico(@RequestBody Disciplina disciplina, @PathVariable Integer academicoId) {
        return disciplinaServico.salvarDisciplina(disciplina, academicoId);
    }

    @GetMapping("/{id}")
    public Disciplina obterDisciplinaPorId(@PathVariable Integer id) {
        return disciplinaServico.obterDisciplinaPorId(id);
    }

    @GetMapping
    public List<Disciplina> listarDisciplinas() {
        return disciplinaServico.listarDisciplinas();
    }

    @DeleteMapping("/{id}")
    public void deletarDisciplina(@PathVariable Integer id) {
        disciplinaServico.deletarDisciplina(id);
    }
}
