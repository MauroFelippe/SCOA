package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ALUNO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Aluno {

    @Id
    @Column(name = "Matricula")
    private Long matricula;

    @ManyToOne
    @JoinColumn(name = "Id_usuario", nullable = false)
    private Usuario usuario;
}