package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Pauta;
import com.teste.teste.Servico.PautaServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pautas")
public class PautaControl {

    @Autowired
    private PautaServico pautaServico;

    @PostMapping("/com-detalhes/{academicoId}/{disciplinaId}")
    public Pauta salvarPautaComDetalhes(
            @RequestBody Pauta pauta,
            @PathVariable Integer academicoId,
            @PathVariable Integer disciplinaId) {
        return pautaServico.salvarPauta(pauta, academicoId, disciplinaId);
    }

    @GetMapping("/{id}")
    public Pauta obterPautaPorId(@PathVariable Integer id) {
        return pautaServico.obterPautaPorId(id);
    }

    @GetMapping
    public List<Pauta> listarPautas() {
        return pautaServico.listarPautas();
    }

    @DeleteMapping("/{id}")
    public void deletarPauta(@PathVariable Integer id) {
        pautaServico.deletarPauta(id);
    }
}
