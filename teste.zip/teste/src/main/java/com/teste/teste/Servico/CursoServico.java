package com.teste.teste.Servico;

import com.teste.teste.Entidade.Curso;
import com.teste.teste.Repositorio.CursoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CursoServico {

    @Autowired
    private CursoRepositorio cursoRepositorio;

    @Transactional
    public Curso salvarCurso(Curso curso) {
        return cursoRepositorio.save(curso);
    }

    @Transactional
    public Curso obterCursoPorId(Integer id) {
        return cursoRepositorio.findById(id).orElse(null);
    }

    @Transactional
    public void deletarCurso(Integer id) {
        cursoRepositorio.deleteById(id);
    }

    @Transactional
    public List<Curso> listarCursos() {
        return cursoRepositorio.findAll();
    }
}
