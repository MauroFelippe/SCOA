package com.teste.teste.Controlador;

import com.teste.teste.Entidade.Academico;
import com.teste.teste.Servico.AcademicoServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/academicos")
public class AcademicoControl {

    @Autowired
    private AcademicoServico academicoServico;

    @PostMapping("/com-usuario/{usuarioId}")
    public Academico salvarAcademicoComUsuario(@RequestBody Academico academico, @PathVariable Integer usuarioId) {
        return academicoServico.salvarAcademico(academico, usuarioId);
    }

    @GetMapping("/{id}")
    public Academico obterAcademicoPorId(@PathVariable Integer id) {
        return academicoServico.obterAcademicoPorId(id);
    }

    @GetMapping
    public List<Academico> listarAcademicos() {
        return academicoServico.listarAcademicos();
    }

    @DeleteMapping("/{id}")
    public void deletarAcademico(@PathVariable Integer id) {
        academicoServico.deletarAcademico(id);
    }
}