package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Pauta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Cod_aula")
    private int codAula;

    @Column(name = "Descricao", nullable = false)
    private String descricao;

    @ManyToOne
    @JoinColumn(name = "Id_funcionario", nullable = false)
    private Academico academico;

    @ManyToOne
    @JoinColumn(name = "Id_disciplina", nullable = false)
    private Disciplina disciplina;
}