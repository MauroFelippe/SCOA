package com.teste.teste.Entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "DISCIPLINA")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Disciplina {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id_disciplina")
    private int idDisciplina;

    @Column(name = "Nome", nullable = false, length = 30)
    private String nome;

    @Column(name = "Horario", nullable = false, length = 5)
    private String horario;

    @Column(name = "Descricao", nullable = false, length = 30)
    private String descricao;

    @Column(name = "Sala", nullable = false, length = 3)
    private String sala;

    @ManyToOne
    @JoinColumn(name = "Id_funcionario", nullable = false)
    private Academico academico;
}